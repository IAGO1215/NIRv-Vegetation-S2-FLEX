from Class import CALVALPrototype

calval_Prototype = CALVALPrototype()
df_Site = calval_Prototype.get_SiteInfo()
calval_Prototype.create_InputSubfolders(df_Site)